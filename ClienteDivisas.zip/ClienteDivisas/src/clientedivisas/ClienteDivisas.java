/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientedivisas;

import InterfazRemota.irDivisas;
import clienteGUI.vPrincipal;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;


public class ClienteDivisas {


    public static void main(String[] args) {

        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(vPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(vPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(vPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(vPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new vPrincipal().setVisible(true);
            }
        });
        
        /*
        try{
           
            String nombre="divisas";
            Registry registry=LocateRegistry.getRegistry("localhost");
            irDivisas divc=(irDivisas) registry.lookup(nombre);
            
            Scanner scan = new Scanner(System.in);
            String opcion, opcion_origen, opcion_salida;
            int i, opcion_cantidad;
            
            do{
            System.out.println("MENU\n");
            System.out.println("==================\n");
            System.out.println("Bienvenido al sistema de gestion de divisas.\n");
            System.out.println("Ingrese una opcion para continuar:\n");
            System.out.println("1) Compra de divisas.\n");
            System.out.println("2) Venta de divisas.\n");
            System.out.println("3) Listar divisas.\n");
            System.out.println("4) Buscar una divisa y desplegar su informacion.\n");
            System.out.println("5) Salir.\n");
            opcion = scan.next();

            switch(opcion){  
                case "1":
               
		do{
                String resultado1[];
                String resultado2[];
                String resultado="";
                
		System.out.println("Usted ha elegido la opcion de comprar divisas\n");
		System.out.println("================================\nEl usuario actualmente posee\n\n");
                    resultado1 = divc.comprar("Cualquier Texto", 1).split(",");
                    resultado="================================\nUsted actualmente Posee:\n================================\n";
                        for(int f=0;f<resultado1.length;f++){
                            resultado= resultado + resultado1[f];
                            resultado= resultado+ "\n";
                        }
                System.out.println(resultado);
                        
                
                
                
                
		System.out.println("================================\n");
		System.out.println("OPCIONES\n\n1)CLP\n2)USD\n3)EUR\n9)Volver\n===================\nSeleccione una opcion que represente la moneda a comprar:\n");
		opcion_origen = scan.next();
                    switch(opcion_origen){
			case "1":
                            do{
				System.out.println("Ingrese el monto a comprar:");		
				opcion_cantidad = scan.nextInt();
				System.out.println("\n");
                            }while(opcion_cantidad<0);
                            do{
				System.out.println("===================\n");
				System.out.println("OPCIONES\n\n2)USD\n3)EUR\n9)Volver\n===================\nSeleccione moneda con la que pagara: ");
				opcion_salida = scan.next();
                                    switch(opcion_salida){
					case "2":
                                            resultado = divc.comprar("CLP-USD-"+opcion_cantidad, 2);  //El submodulo del servicio a ejecutar en el server es el 2.
                                            if(resultado.equals("no_tasa")){
                                                System.out.println("aqui");
                                                System.out.println("La Tasa de cambio no es lo suficiente para realizar la transaccion\n");
                                            }
                                            
                                            if(resultado.equals("no_dinero")){
                                                System.out.println("Usted no dispone del dinero suficiente para realizar la compra\n");
                                            }
                                            
                                            if(resultado.equals("no_cantidad")){
                                                System.out.println("Nuestro Sistema no dispone de la cantidad necesario del tipo solicitado\n");
                                            }
                                            
                                            if(!resultado.equals("no_tasa") && !resultado.equals("no_dinero") && !resultado.equals("no_cantidad")){
                                                System.out.println(resultado);
                                            }
                                            
                                            if(!resultado.equals("no_tasa") && !resultado.equals("no_dinero") && !resultado.equals("no_cantidad")){
                                                resultado1 = resultado.split(",");
                                                System.out.println("================================\nEl usuario antes poseia\n");
                                                System.out.println(resultado1[0]);
                                                System.out.println("\n================================\nEl usuario ahora posee\n");
                                                System.out.println(resultado1[1]);
                                                System.out.println("================================\n");
                                            }
                                            
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";
                                            break;
					
                                        case "3":
                                            resultado = divc.comprar("CLP-EUR-"+opcion_cantidad, 2);  //El submodulo del servicio a ejecutar en el server es el 2.
                                            
                                            if(resultado.equals("no_tasa")){
                                                System.out.println("aqui");
                                                System.out.println("La Tasa de cambio no es lo suficiente para realizar la transaccion\n");
                                            }
                                            
                                            if(resultado.equals("no_dinero")){
                                                System.out.println("Usted no dispone del dinero suficiente para realizar la compra\n");
                                            }
                                            
                                            if(resultado.equals("no_cantidad")){
                                                System.out.println("Nuestro Sistema no dispone de la cantidad necesario del tipo solicitado\n");
                                            }
                                            
                                            if(!resultado.equals("no_tasa") && !resultado.equals("no_dinero") && !resultado.equals("no_cantidad")){
                                                System.out.println(resultado);
                                            }
                                            
                                            if(!resultado.equals("no_tasa") && !resultado.equals("no_dinero") && !resultado.equals("no_cantidad")){
                                                resultado1 = resultado.split(",");
                                                System.out.println("================================\nEl usuario antes poseia\n");
                                                System.out.println(resultado1[0]);
                                                System.out.println("\n================================\nEl usuario ahora posee\n");
                                                System.out.println(resultado1[1]);
                                                System.out.println("================================\n");
                                            }
                                            
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";
					break;
					case "9":
                                            opcion_salida="9";
					break;
					default:
                                            System.out.println("La opcion"+opcion_salida+"no es valida.\n\n");
					break;
                                }
                            
                            }while(!opcion_salida.equals("9"));

                        break;
               
                        case "2":
                            do{
				System.out.println("Ingrese el monto a comprar:");		
				opcion_cantidad = scan.nextInt();
				System.out.println("\n");
                            }while(opcion_cantidad<0);
                            do{
				System.out.println("===================\n");
				System.out.println("OPCIONES\n\n1)CLP\n3)EUR\n9)Volver\n===================\nSeleccione moneda con la que pagara:");
				opcion_salida = scan.next();
                                    switch(opcion_salida){
					case "1":
                                            resultado = divc.comprar("USD-CLP-"+opcion_cantidad, 2);  //El submodulo del servicio a ejecutar en el server es el 2.
                                            
                                            if(resultado.equals("no_tasa")){
                                                System.out.println("aqui");
                                                System.out.println("La Tasa de cambio no es lo suficiente para realizar la transaccion\n");
                                            }
                                            
                                            if(resultado.equals("no_dinero")){
                                                System.out.println("Usted no dispone del dinero suficiente para realizar la compra\n");
                                            }
                                            
                                            if(resultado.equals("no_cantidad")){
                                                System.out.println("Nuestro Sistema no dispone de la cantidad necesario del tipo solicitado\n");
                                            }
                                            
                                            if(!resultado.equals("no_tasa") && !resultado.equals("no_dinero") && !resultado.equals("no_cantidad")){
                                                resultado1 = resultado.split(",");
                                                System.out.println("================================\nEl usuario antes poseia\n");
                                                System.out.println(resultado1[0]);
                                                System.out.println("\n================================\nEl usuario ahora posee\n");
                                                System.out.println(resultado1[1]);
                                                System.out.println("================================\n");
                                            }
                                            
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";
                                            break;
					
                                        case "3":
                                            resultado = divc.comprar("USD-EUR-"+opcion_cantidad, 2);  //El submodulo del servicio a ejecutar en el server es el 2.
                                            
                                            if(resultado.equals("no_tasa")){
                                                System.out.println("aqui");
                                                System.out.println("La Tasa de cambio no es lo suficiente para realizar la transaccion\n");
                                            }
                                            
                                            if(resultado.equals("no_dinero")){
                                                System.out.println("Usted no dispone del dinero suficiente para realizar la compra\n");
                                            }
                                            
                                            if(resultado.equals("no_cantidad")){
                                                System.out.println("Nuestro Sistema no dispone de la cantidad necesario del tipo solicitado\n");
                                            }
                                            
                                            if(!resultado.equals("no_tasa") && !resultado.equals("no_dinero") && !resultado.equals("no_cantidad")){
                                                System.out.println(resultado);
                                            }
                                            
                                            if(!resultado.equals("no_tasa") && !resultado.equals("no_dinero") && !resultado.equals("no_cantidad")){
                                                resultado1 = resultado.split(",");
                                                System.out.println("================================\nEl usuario antes poseia\n");
                                                System.out.println(resultado1[0]);
                                                System.out.println("\n================================\nEl usuario ahora posee\n");
                                                System.out.println(resultado1[1]);
                                                System.out.println("================================\n");
                                            }
                                            
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";
					break;
					case "9":
                                            opcion_salida="9";
					break;
					default:
                                            System.out.println("La opcion"+opcion_salida+"no es valida.\n\n");
					break;
                                }
                            
                            }while(!opcion_salida.equals("9"));

                        break;
                        
                    
                        case "3":
                            do{
				System.out.println("Ingrese el monto a comprar:");		
				opcion_cantidad = scan.nextInt();
				System.out.println("\n");
                            }while(opcion_cantidad<0);
                            do{
				System.out.println("===================\n");
				System.out.println("OPCIONES\n\n1)CLP\n2)USD\n9)Volver\n===================1"
                                        + "1\nSeleccione moneda con la que pagara:");
				opcion_salida = scan.next();
                                    switch(opcion_salida){
					case "1":
                                            resultado = divc.comprar("EUR-CLP-"+opcion_cantidad, 2);  //El submodulo del servicio a ejecutar en el server es el 2.
                                            
                                            if(resultado.equals("no_tasa")){
                                                System.out.println("aqui");
                                                System.out.println("La Tasa de cambio no es lo suficiente para realizar la transaccion\n");
                                            }
                                            
                                            if(resultado.equals("no_dinero")){
                                                System.out.println("Usted no dispone del dinero suficiente para realizar la compra\n");
                                            }
                                            
                                            if(resultado.equals("no_cantidad")){
                                                System.out.println("Nuestro Sistema no dispone de la cantidad necesario del tipo solicitado\n");
                                            }
                                            
                                            if(!resultado.equals("no_tasa") && !resultado.equals("no_dinero") && !resultado.equals("no_cantidad")){
                                                resultado1 = resultado.split(",");
                                                System.out.println("================================\nEl usuario antes poseia\n");
                                                System.out.println(resultado1[0]);
                                                System.out.println("\n================================\nEl usuario ahora posee\n");
                                                System.out.println(resultado1[1]);
                                                System.out.println("================================\n");
                                            }
                                            
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";
                                            break;
					
                                        case "2":
                                            resultado = divc.comprar("EUR-USD-"+opcion_cantidad, 2);  //El submodulo del servicio a ejecutar en el server es el 2.
                                            
                                            if(resultado.equals("no_tasa")){
                                                System.out.println("aqui");
                                                System.out.println("La Tasa de cambio no es lo suficiente para realizar la transaccion\n");
                                            }
                                            
                                            if(resultado.equals("no_dinero")){
                                                System.out.println("Usted no dispone del dinero suficiente para realizar la compra\n");
                                            }
                                            
                                            if(resultado.equals("no_cantidad")){
                                                System.out.println("Nuestro Sistema no dispone de la cantidad necesario del tipo solicitado\n");
                                            }
                                            
                                            if(!resultado.equals("no_tasa") && !resultado.equals("no_dinero") && !resultado.equals("no_cantidad")){
                                                resultado1 = resultado.split(",");
                                                System.out.println("================================\nEl usuario antes poseia\n");
                                                System.out.println(resultado1[0]);
                                                System.out.println("\n================================\nEl usuario ahora posee\n");
                                                System.out.println(resultado1[1]);
                                                System.out.println("================================\n");
                                            }
                                            
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";                  
					break;
					case "9":
                                            opcion_salida="9";
					break;
					default:
                                            System.out.println("La opcion"+opcion_salida+"no es valida.\n\n");
					break;
                                }
                            
                            }while(!opcion_salida.equals("9"));

                        break;
                        
                        
                        case "9":
                        break;

                        default:
                            opcion="-1";
                        break;
                    }
            }while(!opcion_origen.equals("9"));
            case "2":
            break;
            
            //Listar
            case "3":
           
                do{
                String resultado1[];
                String resultado2[];
                String resultado="";
                System.out.println("\nOpcion Listar\n");
                System.out.println("===================\n");
                System.out.println("1)Cuenta Usuario\n2)Disponibilidad Sistema\n3)Cambio Divisas\n4)Volver\n");
                System.out.println("Ingrese su opcion:");
                opcion_origen = scan.next();   
                        if(Integer.parseInt(opcion_origen)!=4){
                     
                        
                        //Si fue opcion 1, mostrar en pantalla de esta forma
                        if(Integer.parseInt(opcion_origen)==1){
                            resultado1 = divc.listar(opcion_origen).split(",");
                            resultado="================================\nUsted actualmente Posee:\n================================\n";
                        for(int f=0;f<resultado1.length;f++){
                            
                            resultado= resultado + resultado1[f];
                            resultado= resultado+ "\n";
                        }
                        System.out.println(resultado);
                        }     
                            
                            

                        //Si fue opcion 2, mostrar en pantalla de esta forma
                        if(Integer.parseInt(opcion_origen)==2){
                            resultado1 = divc.listar(opcion_origen).split(",");
                            resultado="================================\nEl sistema actualmente Posee:\n================================\n";
                        for(int f=0;f<resultado1.length;f++){
                            
                            resultado= resultado + resultado1[f];
                            resultado= resultado+ "\n";
                        }
                        System.out.println(resultado);
                        }
                        
                        
                        //Si fue opcion 3, mostrar en pantalla de esta forma
                        if(Integer.parseInt(opcion_origen)==3){
                            resultado1 = divc.listar(opcion_origen).split(",");
                        for(int f=0;f<resultado1.length;f++){
                            resultado2=resultado1[f].split("-");
                            resultado=resultado + resultado2[0]+" corresponde a "+resultado2[2]+" de la moneda "+resultado2[1]+" \n";
                        }
                        System.out.println(resultado);
                        }
                        

                    }
               
                }while(Integer.parseInt(opcion_origen)!=4);
            break;
              
        }
            
        }while(!opcion.equals("5"));
    
        }catch(Exception e){
            System.err.println("Error en el Cliente");
            e.printStackTrace();
        }
       */ 
    }
   
}
