/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientedivisas;

import InterfazRemota.irDivisas;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author pc0131
 */
public class ClienteDivisas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       /* if(System.getSecurityManager()==null){
            System.setSecurityManager(new SecurityManager());
        }
*/
        try{
            String nombre="divisas";
            Registry registry=LocateRegistry.getRegistry("localhost");
            irDivisas divc=(irDivisas) registry.lookup(nombre);
            System.out.println(divc.saludo("I"));
            System.out.println("potencia: "+divc.potencia(2, 4));
            //calc.potencia(2, 4);
        }catch(Exception e){
            System.err.println("Error en el Cliente");
            e.printStackTrace();
        }
    }
    
}
