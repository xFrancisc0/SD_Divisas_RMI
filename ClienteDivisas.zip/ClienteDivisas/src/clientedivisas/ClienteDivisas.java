/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientedivisas;

import InterfazRemota.irDivisas;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;


public class ClienteDivisas {


    public static void main(String[] args) {

        try{
            String nombre="divisas";
            Registry registry=LocateRegistry.getRegistry("localhost");
            irDivisas divc=(irDivisas) registry.lookup(nombre);
            
            Scanner scan = new Scanner(System.in);
            String opcion, opcion_origen, opcion_salida;
            int i, opcion_cantidad;
            
            do{
            System.out.println("MENU\n");
            System.out.println("==================\n");
            System.out.println("Bienvenido al sistema de gestion de divisas.\n");
            System.out.println("Ingrese una opcion para continuar:\n");
            System.out.println("1) Compra de divisas.\n");
            System.out.println("2) Venta de divisas.\n");
            System.out.println("3) Listar divisas.\n");
            System.out.println("4) Buscar una divisa y desplegar su informacion.\n");
            System.out.println("5) Salir.\n");
            opcion = scan.next();

            switch(opcion){  
                case "1":
               
		do{
		System.out.println("Usted ha elegido la opcion de comprar divisas\n");
		System.out.println("================================\nEl usuario actualmente posee\n\n");
                System.out.println(divc.comprar("Cualquier Texto", 1)); 
		System.out.println("================================\n");
		System.out.println("OPCIONES\n\n1)CLP\n2)USD\n3)EUR\n9)Volver\n===================\nSeleccione una opcion que represente la moneda a comprar:\n");
		opcion_origen = scan.next();
                    switch(opcion_origen){
			case "1":
                            do{
				System.out.println("Ingrese el monto a comprar:");		
				opcion_cantidad = scan.nextInt();
				System.out.println("\n");
                            }while(opcion_cantidad<0);
                            do{
				System.out.println("===================\n");
				System.out.println("OPCIONES\n\n2)USD\n3)EUR\n9)Volver\n===================\nSeleccione moneda con la que pagara: ");
				opcion_salida = scan.next();
                                    switch(opcion_salida){
					case "2":
                                            System.out.println(divc.comprar("CLP-USD-"+opcion_cantidad, 2));  //El submodulo del servicio a ejecutar en el server es el 2.
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";
                                            break;
					
                                        case "3":
                                            System.out.println(divc.comprar("CLP-EUR-"+opcion_cantidad, 2));  //El submodulo del servicio a ejecutar en el server es el 2.
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";
					break;
					case "9":
                                            opcion_salida="9";
					break;
					default:
                                            System.out.println("La opcion"+opcion_salida+"no es valida.\n\n");
					break;
                                }
                            
                            }while(!opcion_salida.equals("9"));

                        break;
               
                        case "2":
                            do{
				System.out.println("Ingrese el monto a comprar:");		
				opcion_cantidad = scan.nextInt();
				System.out.println("\n");
                            }while(opcion_cantidad<0);
                            do{
				System.out.println("===================\n");
				System.out.println("OPCIONES\n\n1)CLP\n3)EUR\n9)Volver\n===================\nSeleccione moneda con la que pagara:");
				opcion_salida = scan.next();
                                    switch(opcion_salida){
					case "1":
                                            System.out.println(divc.comprar("USD-CLP-"+opcion_cantidad, 2));  //El submodulo del servicio a ejecutar en el server es el 2.
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";
                                            break;
					
                                        case "3":
                                            System.out.println(divc.comprar("USD-EUR-"+opcion_cantidad, 2));  //El submodulo del servicio a ejecutar en el server es el 2.
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";
					break;
					case "9":
                                            opcion_salida="9";
					break;
					default:
                                            System.out.println("La opcion"+opcion_salida+"no es valida.\n\n");
					break;
                                }
                            
                            }while(!opcion_salida.equals("9"));

                        break;
                        
                    
                        case "3":
                            do{
				System.out.println("Ingrese el monto a comprar:");		
				opcion_cantidad = scan.nextInt();
				System.out.println("\n");
                            }while(opcion_cantidad<0);
                            do{
				System.out.println("===================\n");
				System.out.println("OPCIONES\n\n1)CLP\n2)USD\n9)Volver\n===================1"
                                        + "1\nSeleccione moneda con la que pagara:");
				opcion_salida = scan.next();
                                    switch(opcion_salida){
					case "1":
                                            System.out.println(divc.comprar("EUR-CLP-"+opcion_cantidad, 2));  //El submodulo del servicio a ejecutar en el server es el 2.
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";
                                            break;
					
                                        case "2":
                                            System.out.println(divc.comprar("EUR-USD-"+opcion_cantidad, 2));  //El submodulo del servicio a ejecutar en el server es el 2.
                                            System.out.println("Ingrese cualquier cosa para continuar: ");
                                            i = scan.nextInt();
                                            opcion_salida="9";
                                            opcion_origen="9";                  
					break;
					case "9":
                                            opcion_salida="9";
					break;
					default:
                                            System.out.println("La opcion"+opcion_salida+"no es valida.\n\n");
					break;
                                }
                            
                            }while(!opcion_salida.equals("9"));

                        break;
                        
                        
                        case "9":
                        break;

                        default:
                            opcion="-1";
                        break;
                    }
            }while(!opcion_origen.equals("9"));
            case "2":
            break;
            case "3":
           
                do{
                System.out.println("\nOpcion Listar\n");
                System.out.println("===================\n");
                System.out.println("1)Cuenta Usuario\n2)Disponibilidad Sistema\n3)Cambio Divisas\n4)Volver\n");
                System.out.println("Ingrese su opcion:");
                opcion_origen = scan.next();   
                        if(Integer.parseInt(opcion_origen)!=4){
                        System.out.println(divc.listar(opcion_origen));
                        }
               
                }while(Integer.parseInt(opcion_origen)!=4);
            break;
              
        }
            
        }while(!opcion.equals("5"));
    
        }catch(Exception e){
            System.err.println("Error en el Cliente");
            e.printStackTrace();
        }
           
    }
    
}
