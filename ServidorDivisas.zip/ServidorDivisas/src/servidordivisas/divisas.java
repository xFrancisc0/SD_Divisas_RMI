/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidordivisas;

import InterfazRemota.irDivisas;//importado por Libraries Add JAR/folder

/**
 *
 * @author pc0131
 */
public class divisas implements irDivisas{
    //constructor
    public divisas(){
        super();//construye igual como lo hace el padre
    }
    @Override //Sobreescribe  para indicar si se encuentra error
    public int factorial(int n){
        int i, fact;
        fact=1;
        for(i=1;i<=n;i++){
        fact=i*fact;
    }
    return fact;
    }
    @Override 
    public float potencia(float base, int exponente){
        float Potencia;
        int k;
        if (base==0) Potencia=0;
        else{
        Potencia=1;
        for(k=0;k<exponente;k++)Potencia*=base;
        }
      return Potencia;
    }
    @Override
    public String saludo(String nombre){
        String salu2=nombre+",asdasd.";
        return salu2;
    }
}
