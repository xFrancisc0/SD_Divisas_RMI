
package servidordivisas;

import InterfazRemota.irDivisas;//importado por Libraries Add JAR/folder
import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.PrintStream;
import static java.lang.Float.parseFloat;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;

       

public class divisas implements irDivisas{
    //constructor
    public divisas(){
        super();//construye igual como lo hace el padre
    }
     /*
    metodo que permite realizar los procesos de compra
    recibe arrayList:
        -sistem_moneda (la lista donde estan los tipo moneda del sistema)
        -sistem_cantidad (la cantidad correspondiente del tipo de moneda que posee el sistema)
        -user_moneda (lista con los tipo moneda del usuario)
        -user_cantidad (lista con la cantidad de monedas del usuario)
     String moneda_compra (la moneda que se comprara)
      String_moneda_pago (el tipo moneda con el que se pagara)
        int cantidad (la cantidad a comprar)
    
    retorna un string con los detalles de la compra
    */
    
    private String comprar_divisas(ArrayList <String> sistem_moneda, ArrayList <String> sistem_cantidad,  ArrayList <String> user_moneda, ArrayList <String> user_cantidad, String moneda_compra, String moneda_pago, int cantidad){
        String result = null;
        int i=0;
        
        //IMPRESIONES DE TRAZABILIDAD
        System.out.println("Datos recibidos en comprar_divisas\n");
        
        for(i=0;i<sistem_moneda.size();i++){
                System.out.println("Sistem_moneda_get(x): "+sistem_moneda.get(i));
                System.out.println("Sistem_cantidad_get(x): "+sistem_cantidad.get(i));
                
            }
        System.out.println("\n");
        
        for(i=0;i<user_moneda.size();i++){
                System.out.println("user_moneda_get(x): "+user_moneda.get(i));
                System.out.println("user_cantidad_get(x): "+user_cantidad.get(i));
                
            }
        System.out.println("\n");
        
        System.out.println("moneda_compra: "+moneda_compra);
        System.out.println("moneda_pago: "+moneda_pago);
        System.out.println("cantidad: " +cantidad);
        System.out.println("\n");
        
        
        
            
        ArrayList <String> cambio= new ArrayList <>();//guardaremos los valores de cambio aqui
        ArrayList <String> c_origen = new ArrayList <>();//guardaremos los tipo monedas de origen de cambio
        ArrayList <String> c_destino = new ArrayList <>();//guardaremos los tipos monedas de destino de cambio aqui
        
        i=0;
        int j=0, l=0;//iteradores
	float cantidad_usuario_cambio, cantidad_usuario_origen, cantidad_sistema,cantidad_sistema_pago,tipo_cambio_aux ;
        String spl[], line;//lo usaremos cada vez que queramos hacer una division de strings
	float conversion;
        try {
            LineNumberReader input_conversion = new LineNumberReader(new FileReader("./datos/conversion.txt"));
            while((line = input_conversion.readLine())!=null) {//mientras exista una siguiente linea
                if(line.equals("")) //Si hay bug al leer lineas no se toma en cuenta
                    continue;
                spl=line.split(" ");//separamos la linea de forma tipo_moneda_orige tipo_moneda_destino tasa_cambio en spl
                c_origen.add(spl[0]);//guardamos los tipo_moneda_origen aqui
                c_destino.add(spl[1]);//guardamos los tipo_moneda_destino aqui
                cambio.add(spl[2]);//guardamos las tasa_cambio aqui
            }
            
        //IMPRESIONES DE TRAZABILIDAD
        System.out.println("Lectura de input_conversion");
        for(i=0;i<c_origen.size();i++){
                System.out.println("c_origen.size(x): "+c_origen.get(i));
                System.out.println("cambio(x): "+cambio.get(i));
                System.out.println("c_destino(x): "+c_destino.get(i));
                System.out.println("===================================");
            }    
            
           int aux;    
           i=0;
           j=0;
           l=0;	//Buscamos en la  estructura user de tipo entidad la posicion del tipo de moneda_pago ingresado con la que se pagarÃ¡
	
        while(!(moneda_pago.equals(user_moneda.get(i))) && i<user_moneda.size()){
		i++;	
	}
        
	//buscamos en la estructura sistem de tipo entidad la posicion de moneda_compra ingresado que se comprarÃ¡
	while(!(moneda_compra.equals(sistem_moneda.get(j))) && j<sistem_moneda.size()){
		j++;	
	}
        
        l=0;
        while(!(moneda_compra.equals(c_origen.get(l)) && moneda_pago.equals(c_destino.get(l)))){ 
					//buscamos los tipos de moneda que se utilizaran y su tasa de cambio y vemos que quedara en la posicion l(L)
				l++;		
	}
        
        
        
        //IMPRESIONES DE TRAZABILIDAD
        System.out.println("\nValores de las busquedas de las coincidencias: ");
        System.out.println("i: "+i);
        System.out.println("j: "+j);
        System.out.println("l: "+l);
        System.out.println("\n");
        
        //IMPRESIONES DE TRAZABILIDAD
        System.out.println("\nValores de conversion: ");
        System.out.println("cambio"+cambio.get(l));
        System.out.println("Float.parseFloat(cambio.get(l)): "+Float.parseFloat(cambio.get(l)));
        //Hay error en PARSEFLOAT!

        
        //realizamos la  conversion de divisas		
	conversion=cantidad*(Float.parseFloat(cambio.get(l)));
        
        //IMPRESIONES DE TRAZABILIDAD
        System.out.println("\nValores de conversion: ");
        System.out.println("conversion: "+conversion);
        System.out.println("\n");
        
        	if(conversion<1){//veemos si la conversion da para realizar la compra y no quedemos con que tenemos que pagar o compra algo menor que 1
			
			result="La Tasa de cambio no es lo suficiente para realizar la transaccion\n";
			
		return result;	//retornamos result
		}
                
           	if(conversion>(parseFloat(user_cantidad.get(i)))){ //comparamos si es que disponemos con el dinero a pagar, sino desplegamos mensaje
		
		
		result="Usted no dispone del dinero suficiente para realizar la compra\n";
		return result;//retornamos result
	}else{
		
                      //IMPRESIONES DE TRAZABILIDAD
                        System.out.println("\nValores de conversion: ");
                        System.out.println("sistem_cantidad.get(j): "+parseFloat(sistem_cantidad.get(j)));
                        System.out.println("\n");    
                
                float auxf=Float.parseFloat(sistem_cantidad.get(j));
                int auxi=(int)Math.round(auxf);
                    
                //IMPRESIONES DE TRAZABILIDAD
                        System.out.println("\nValores de conversion: ");
                        System.out.println("auxf: "+auxf);
                        System.out.println("auxi: "+auxi);
                        System.out.println("\n");  
                
		if(cantidad>=auxi){//comparamos si el sistema dispone de la cantidad suficiente de lo que demandamos, sino despliega mensaje
			
			result="Nuestro Sistema no dispone de la cantidad necesario del tipo solicitado\n";
	
			return result;//retornamos result
		}else{
				
		
                             //realizamos los calculos de compra por parte del usuario y venta por parte del sistema
				
				cantidad_usuario_cambio = parseFloat(user_cantidad.get(j))+cantidad; //sumamos la cantidad comprada del tipo deseado al usuario
				cantidad_usuario_origen = parseFloat(user_cantidad.get(i))-conversion; //restamos la cantidad que se debe pagar del usuario
				cantidad_sistema = parseFloat(sistem_cantidad.get(j))-cantidad;	//restamos la cantidad que se vendio del sistema
				cantidad_sistema_pago = parseFloat(sistem_cantidad.get(i))+conversion; //sumamos la cantidad que se recibio por la venta
			}
			//ya que tenemos almacenados los valores de los archivos usuario.txt y sistema.txt en los arreglos correspondiente
                        // y procedemos con el reemplazo de los archivos con los datos actualizados
                           File us, sis;
                           us= new File("./datos/usuario.txt");
                           sis = new File("./datos/sistema.txt");
			if(us.delete() && sis.delete()){ 
			//si fueron eliminados usuario.txt y sistema.txt 
			//Los creamos nuevamente con los datos actualizados 
			PrintStream nuevo_cliente= new PrintStream("./datos/usuario.txt");
			PrintStream nuevo_servidor=new PrintStream("./datos/sistema.txt");
			
			String cantidad_usuario_cambioaux;//ya que los calculos numericos fueron con float necesitamos parsearlos a string nuevamente
			String cantidad_usuario_origenaux;

				cantidad_usuario_cambioaux=Float.toString(cantidad_usuario_cambio);
				cantidad_usuario_origenaux=Float.toString(cantidad_usuario_origen);

				// Concatenamos los detalles de la compra y Esto se devolvera al cliente
				result= "================================\nEl usuario antes poseia\n";
				result+= user_cantidad.get(j);
				result+=" ";
				result+= moneda_compra ;
				result+= "\n";
				result+= user_cantidad.get(i) ;
				result+= " ";
				result+= moneda_pago ;
				result+= "\n================================\nEl usuario ahora posee\n" ;
				result+= cantidad_usuario_cambioaux ;
				result+= " ";
				result+= moneda_compra ;
				result+= "\n";
				result+= cantidad_usuario_origenaux ;
				result+= " ";
				result+= moneda_pago;
				result+= "\n================================\nIngrese un numero para continuar.\n\n\n" ;
				
				//Debido a que en los arreglos no se encuentran actualizados los valores de la compra necesitamos saber
                                //donde se realizaron y esto fue en las posicione i y j
                                //para que al momento de guardarlos en los archivos usuario.txt y sistema.txt
                                //usemos los valores actualizado y no los que contienen los arreglos
			for(l=0;l<3;l++){
			
				if(l==j){//buscamos donde sistema entrego la cantidad de monedas compradas y donde el usuario aumenta su saldo de moneda comprada, que estan en la posicion j para actualizarlo en el txt
					nuevo_cliente.println(user_moneda.get(l)+" "+cantidad_usuario_cambio+"\n");
					nuevo_servidor.println(sistem_moneda.get(l)+" "+cantidad_sistema+"\n");
				
				}else{
					if(l==i){//buscamos donde el sistema gano por la venta y donde el usuario pago con un tipo de moneda que esta almacenado en la posicion i, para escribirlo en el txt
                                            nuevo_cliente.println(user_moneda.get(l)+" "+cantidad_usuario_origen+"\n");
                                            nuevo_servidor.println(sistem_moneda.get(l)+" "+cantidad_sistema_pago+"\n");
						
					}else{//sino, se escribe directamente lo que se tiene almacenado ya que no se ha realizado ninguna modificacion en los demas campos
					
					nuevo_cliente.println(user_moneda.get(l)+" "+user_cantidad.get(l)+"\n");
					nuevo_servidor.println(sistem_moneda.get(l)+" "+sistem_cantidad.get(l)+"\n");
				
				}
				
			}
		}
                        //cerramos los archivos
			nuevo_cliente.close();
			nuevo_servidor.close();
			
		}
		}     
            input_conversion.close();
          
        } catch (Exception ex) {
            ex.printStackTrace();
        }
 return result;//si todo salio bien se retornara los detalles de la compra
    }
    @Override
   
    
    
       /*
        metodo principal de compra 
           recibe un String que corresponde a una cadena compuesta por moneda_origen-moneda_destino-cantidad
                   un int que corresponde a una opcion para este metodo si es 1 solo devuelve los valores del usuario
                                    si es 2 procede compra
            devuelve un string con los detalle de la compra 
    */
    public String comprar(String a, int b){
        String result="";
     
        int i=0;
        ArrayList <String> lista_usuario_moneda= new ArrayList<>();//donde guardaremos los tipo_moneda del usuario
        ArrayList <String> lista_usuario_cantidad= new ArrayList<>();//donde guardaremos la cantidad de la moneda del usuario
        ArrayList <String> lista_servidor_moneda= new ArrayList<>();//donde guardaremos los tipo_moneda del sistema
        ArrayList <String> lista_servidor_cantidad= new ArrayList<>();//donde guardaremos la cantidad de monedas del sistema
       
    if(b==1){//si b es 1 solo retornaremos los valores que guarda usuario.txt para que sea visible por el cliente
   
   
          try {
            LineNumberReader input_user = new LineNumberReader(new FileReader("./datos/usuario.txt"));
            String line;
            while((line = input_user.readLine())!=null) {
                result=result+line;
                result=result+"\n";
            }
            input_user.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
      return result;//le devolvemos al usuario los valores de usuario.txt
   
    
    }
	
    if(b==2){//si b es 2 realizaremos la compra
        

        
          try {
            LineNumberReader input_user = new LineNumberReader(new FileReader("./datos/usuario.txt"));
            LineNumberReader input_server = new LineNumberReader(new FileReader("./datos/sistema.txt"));
            String line;
            String moneda[]=new String[2];
            //primero pasaremos los datos de usuario.txt a lista_usuario_moneda y lista_usuario_cantidad
            
            while((line = input_user.readLine())!=null ) {
                if(line.equals("")) //Si hay bug al leer lineas no se toma en cuenta
                    continue;
                
            moneda=line.split(" ");

            lista_usuario_moneda.add(moneda[0]);
            lista_usuario_cantidad.add(moneda[1]);

            }
       i=0;
            while((line = input_server.readLine())!=null) {
                if(line.equals("")) //Si hay bug al leer lineas no se toma en cuenta
                    continue;
                moneda=line.split(" ");
                lista_servidor_moneda.add(moneda[0]);
                lista_servidor_cantidad.add(moneda[1]);    
            }
            
            
            //IMPRESIONES DE TRAZABILIDAD
            System.out.println("Datos leidos de servidor.txt y guardados en arraylist");
            for(i=0;i<lista_servidor_moneda.size();i++){
                System.out.println(lista_servidor_moneda.get(i));
                System.out.println(lista_servidor_cantidad.get(i));
                
            }
            System.out.println("Datos leidos de usuario.txt y guardados en arraylist");
            for(i=0;i<lista_usuario_moneda.size();i++){
                System.out.println(lista_usuario_moneda.get(i));
                System.out.println(lista_usuario_cantidad.get(i));
                
            }
            
            input_user.close();
            input_server.close();
            moneda=a.split("-");
            
            //IMPRESIONES DE TRAZABILIDAD
            System.out.println("Datos a enviar a comprar_divisas\n");
            System.out.println(moneda[0]);
            System.out.println(moneda[1]);
            System.out.println(moneda[2]);
            //llamamos al metodo comprar_divisas que realizara lo importante en la compra
            //y guardaremos lo que retorne en result
            result=comprar_divisas(lista_servidor_moneda,lista_servidor_cantidad, lista_usuario_moneda,lista_usuario_cantidad, moneda[0],moneda[1],parseInt(moneda[2]));
            return result;
            
            
          } catch (Exception ex) {
            ex.printStackTrace();
        }
    }   
   
        return result;//retornaremos result al cliente
    }
    
}