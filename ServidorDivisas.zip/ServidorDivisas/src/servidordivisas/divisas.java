
package servidordivisas;

import InterfazRemota.irDivisas;//importado por Libraries Add JAR/folder
import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.PrintStream;
import static java.lang.Float.parseFloat;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;

       

public class divisas implements irDivisas{
    //constructor
    public divisas(){
        super();//construye igual como lo hace el padre
    }
    
    private String comprar_divisas(ArrayList <String> sistem_moneda, ArrayList <String> sistem_cantidad,  ArrayList <String> user_moneda, ArrayList <String> user_cantidad, String moneda_compra, String moneda_pago, int cantidad){
        String result = null;
        int i=0;
        
        //IMPRESIONES DE TRAZABILIDAD
        System.out.println("Datos recibidos en comprar_divisas\n");
        
        for(i=0;i<sistem_moneda.size();i++){
                System.out.println("Sistem_moneda_get(x): "+sistem_moneda.get(i));
                System.out.println("Sistem_cantidad_get(x): "+sistem_cantidad.get(i));
                
            }
        System.out.println("\n");
        
        for(i=0;i<user_moneda.size();i++){
                System.out.println("user_moneda_get(x): "+user_moneda.get(i));
                System.out.println("user_cantidad_get(x): "+user_cantidad.get(i));
                
            }
        System.out.println("\n");
        
        System.out.println("moneda_compra: "+moneda_compra);
        System.out.println("moneda_pago: "+moneda_pago);
        System.out.println("cantidad: " +cantidad);
        System.out.println("\n");
        
        
        
            
        ArrayList <String> cambio= new ArrayList <>();
        ArrayList <String> c_origen = new ArrayList <>();
        ArrayList <String> c_destino = new ArrayList <>();
        
        i=0;
        int j=0, l=0;//iteradores
	float cantidad_usuario_cambio, cantidad_usuario_origen, cantidad_sistema,cantidad_sistema_pago,tipo_cambio_aux ;
        String spl[], line;
	float conversion;
        try {
            LineNumberReader input_conversion = new LineNumberReader(new FileReader("./datos/conversion.txt"));
            while((line = input_conversion.readLine())!=null) {
                if(line.equals("")) //Si hay bug al leer lineas no se toma en cuenta
                    continue;
                spl=line.split(" ");
                c_origen.add(spl[0]);
                c_destino.add(spl[1]);
                cambio.add(spl[2]); 
            }
            
        //IMPRESIONES DE TRAZABILIDAD
        System.out.println("Lectura de input_conversion");
        for(i=0;i<c_origen.size();i++){
                System.out.println("c_origen.size(x): "+c_origen.get(i));
                System.out.println("cambio(x): "+cambio.get(i));
                System.out.println("c_destino(x): "+c_destino.get(i));
                System.out.println("===================================");
            }    
            
           int aux;    
           i=0;
           j=0;
           l=0;	//Buscamos en la  estructura user de tipo entidad la posicion del tipo de moneda_pago ingresado con la que se pagarÃ¡
	
        while(!(moneda_pago.equals(user_moneda.get(i))) && i<user_moneda.size()){
		i++;	
	}
        
	//buscamos en la estructura sistem de tipo entidad la posicion de moneda_compra ingresado que se comprarÃ¡
	while(!(moneda_compra.equals(sistem_moneda.get(j))) && j<sistem_moneda.size()){
		j++;	
	}
        
        l=0;
        while(!(moneda_compra.equals(c_origen.get(l)) && moneda_pago.equals(c_destino.get(l)))){ 
					//buscamos en el archivo conversion.txt los tipos de moneda que se utilizaran y su tasa de cambio y lo guardamos en tasa_cambio
		l++;		
	}
        
        
        
        //IMPRESIONES DE TRAZABILIDAD
        System.out.println("\nValores de las busquedas de las coincidencias: ");
        System.out.println("i: "+i);
        System.out.println("j: "+j);
        System.out.println("l: "+l);
        System.out.println("\n");
        
        //IMPRESIONES DE TRAZABILIDAD
        System.out.println("\nValores de conversion: ");
        System.out.println("cambio"+cambio.get(l));
        System.out.println("Float.parseFloat(cambio.get(l)): "+Float.parseFloat(cambio.get(l)));
        //Hay error en PARSEFLOAT!

        
        //realizamos la  conversion de divisas		
	conversion=cantidad*(Float.parseFloat(cambio.get(l)));
        
        //IMPRESIONES DE TRAZABILIDAD
        System.out.println("\nValores de conversion: ");
        System.out.println("conversion: "+conversion);
        System.out.println("\n");
        
        	if(conversion<1){
			result="no_tasa";
			//printf("Conversion == %f",conversion);
		return result;	
		}
                
           	if(conversion>(parseFloat(user_cantidad.get(i)))){ //comparamos si es que disponemos con el dinero a pagar, sino desplegamos mensaje
		//printf("Usted dispone de %s de la moneda %s no puede realizar la compra\n\n", user[i].cantidad,user[i].tipo_moneda);
		//system("pause");
		
		result="no_dinero";
		return result;
	}else{
		
                      //IMPRESIONES DE TRAZABILIDAD
                        System.out.println("\nValores de conversion: ");
                        System.out.println("sistem_cantidad.get(j): "+parseFloat(sistem_cantidad.get(j)));
                        System.out.println("\n");    
                
                float auxf=Float.parseFloat(sistem_cantidad.get(j));
                int auxi=(int)Math.round(auxf);
                    
                //IMPRESIONES DE TRAZABILIDAD
                        System.out.println("\nValores de conversion: ");
                        System.out.println("auxf: "+auxf);
                        System.out.println("auxi: "+auxi);
                        System.out.println("\n");  
                
		if(cantidad>=auxi){//comparamos si el sistema dispone de la cantidad suficiente de lo que demandamos, sino despliega mensaje
			
			result="no_cantidad";
	
			return result;
		}else{
				
		
			
				cantidad_usuario_cambio = parseFloat(user_cantidad.get(j))+cantidad; //sumamos la cantidad comprada del tipo deseado al usuario
				cantidad_usuario_origen = parseFloat(user_cantidad.get(i))-conversion; //restamos la cantidad que se debe pagar del usuario
				cantidad_sistema = parseFloat(sistem_cantidad.get(j))-cantidad;	//restamos la cantidad que se vendio del sistema
				cantidad_sistema_pago = parseFloat(sistem_cantidad.get(i))+conversion; //sumamos la cantidad que se recibio por la venta
			}
			//printf("i=%i J=%i\n\n",i,j);
			//cerramos f y f2 para poder realizar la eliminacion de estos
                           File us, sis;
                           us= new File("./datos/usuario.txt");
                           sis = new File("./datos/sistema.txt");
			if(us.delete() && sis.delete()){ 
			//si fueron eliminados usuario.txt y sistema.txt 
			//Los creamos nuevamente con los datos actualizados 
			PrintStream nuevo_cliente= new PrintStream("./datos/usuario.txt");
			PrintStream nuevo_servidor=new PrintStream("./datos/sistema.txt");
			
			String cantidad_usuario_cambioaux;
			String cantidad_usuario_origenaux;

				cantidad_usuario_cambioaux=Float.toString(cantidad_usuario_cambio);
				cantidad_usuario_origenaux=Float.toString(cantidad_usuario_origen);

		
                        
                        	// Esto se devolvera al cliente
                                result="";
				result+= user_cantidad.get(j);
				result+=" ";
				result+= moneda_compra ;
				result+= " y ";
				result+= user_cantidad.get(i) ;
				result+= " ";
				result+= moneda_pago ;
				result+= ",";
				result+= cantidad_usuario_cambioaux ;
				result+= " ";
				result+= moneda_compra ;
				result+= " y ";
				result+= cantidad_usuario_origenaux ;
				result+= " ";
				result+= moneda_pago;
				result+= " ";
			
                        
                        
                        
			for(l=0;l<3;l++){
			
				if(l==j){//buscamos donde sistema entrego la cantidad de monedas compradas y donde el usuario aumenta su saldo de moneda comprada, que estan en la posicion j para actualizarlo en el txt
					nuevo_cliente.println(user_moneda.get(l)+" "+cantidad_usuario_cambio+"\n");
					nuevo_servidor.println(sistem_moneda.get(l)+" "+cantidad_sistema+"\n");
				
				}else{
					if(l==i){//buscamos donde el sistema gano por la venta y donde el usuario pago con un tipo de moneda que esta almacenado en la posicion i, para escribirlo en el txt
                                            nuevo_cliente.println(user_moneda.get(l)+" "+cantidad_usuario_origen+"\n");
                                            nuevo_servidor.println(sistem_moneda.get(l)+" "+cantidad_sistema_pago+"\n");
						
					}else{//sino, se escribe directamente lo que se tiene almacenado ya que no se ha realizado ninguna modificacion en los demas campos
					
					nuevo_cliente.println(user_moneda.get(l)+" "+user_cantidad.get(l)+"\n");
					nuevo_servidor.println(sistem_moneda.get(l)+" "+sistem_cantidad.get(l)+"\n");
				
				}
				
			}
		}
			nuevo_cliente.close();
			nuevo_servidor.close();
			
		}
		}     
            input_conversion.close();
          
        } catch (Exception ex) {
            ex.printStackTrace();
        }
 return result;
    }
    
    @Override
 
    
    public String comprar(String a, int b){
        String result="";
     
        int i=0;
        ArrayList <String> lista_usuario_moneda= new ArrayList<String>();
        ArrayList <String> lista_usuario_cantidad= new ArrayList<String>();
        ArrayList <String> lista_servidor_moneda= new ArrayList<String>();
        ArrayList <String> lista_servidor_cantidad= new ArrayList<String>();
       
    if(b==1){
      result = listar_usuario();
      return result;
    }
	
    if(b==2){
        
        /*
                
            try {
                 LineNumberReader lnr_user = new LineNumberReader(new FileReader("./datos/usuario.txt"));
                LineNumberReader lnr_server= new LineNumberReader(new FileReader("./datos/sistema.txt"));
                do{
                    strng=lnr_user.readLine();
                    moneda = strng.split(" ");
                    lista_usuario_moneda.add(moneda[1]);
                    lista_usuario_cantidad.add(moneda[3]);
                    
                }while(strng!=null);  
                do{
                    strng_2=lnr_server.readLine();
                    moneda = strng.split(" ");
                    lista_servidor_moneda.add(moneda[1]);
                    lista_servidor_cantidad.add(moneda[3]);
                }while(strng_2!=null);
                for(i=0;i<lista_servidor_moneda.size();i++){
                    result=result+lista_usuario_moneda.get(i);
                    result=result+" ";
                    result=result+lista_usuario_cantidad.get(i);
                }
                
                //Inicialmente debo rescatar los datos del usuario y del server.
                /*
                entidad dinero_servidor[3];  //Creo un vector que me almacene los datos de dinero del servidor
                entidad dinero_usuario[3];	 //Creo un vector que me almacene los datos de dinero del usuario
                char moneda_compra[4], moneda_pago[4], str[20];
                char * *result_1;
                char resultado[1000];
                int cantidad;
                char *v1, *v2, *v3;
                
                FILE * f=fopen("./datos/usuario.txt","a+");
                FILE * f2=fopen("./datos/sistema.txt","a+");
                rescata_dinero(dinero_servidor,f2);  //Lleno el vector de dinero del servidor con los datos del almacen
                rescata_dinero(dinero_usuario,f);    //Lleno el vector de dinero del usuario con los datos del almacen
                
                sprintf(str,"%s",argp->str);         //Recupero el string que envie al server
                v1 = strtok(str, "-");
                v2 = strtok(NULL,"-");
                v3 = strtok(NULL,"-");
                
                result_1 = div_comprar(dinero_servidor,dinero_usuario,v1,v2,atoi(v3),f,f2);
                
                sprintf(resultado,"%s", (char *) *result_1);
                
                result = resultado;
                return &result;
                }
                     return result;
            } catch (FileNotFoundException ex) {
                Logger.getLogger(divisas.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(divisas.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                
            }
*/
        
          try {
            LineNumberReader input_user = new LineNumberReader(new FileReader("./datos/usuario.txt"));
            LineNumberReader input_server = new LineNumberReader(new FileReader("./datos/sistema.txt"));
            String line;
            String moneda[]=new String[2];

            while((line = input_user.readLine())!=null ) {
                if(line.equals("")) //Si hay bug al leer lineas no se toma en cuenta
                    continue;
                
            moneda=line.split(" ");

            lista_usuario_moneda.add(moneda[0]);
            lista_usuario_cantidad.add(moneda[1]);

            }
       i=0;
            while((line = input_server.readLine())!=null) {
                if(line.equals("")) //Si hay bug al leer lineas no se toma en cuenta
                    continue;
                moneda=line.split(" ");
                lista_servidor_moneda.add(moneda[0]);
                lista_servidor_cantidad.add(moneda[1]);    
            }
            
            
            //IMPRESIONES DE TRAZABILIDAD
            System.out.println("Datos leidos de servidor.txt y guardados en arraylist");
            for(i=0;i<lista_servidor_moneda.size();i++){
                System.out.println(lista_servidor_moneda.get(i));
                System.out.println(lista_servidor_cantidad.get(i));
                
            }
            System.out.println("Datos leidos de usuario.txt y guardados en arraylist");
            for(i=0;i<lista_usuario_moneda.size();i++){
                System.out.println(lista_usuario_moneda.get(i));
                System.out.println(lista_usuario_cantidad.get(i));
                
            }
            
            input_user.close();
            input_server.close();
            moneda=a.split("-");
            
            //IMPRESIONES DE TRAZABILIDAD
            System.out.println("Datos a enviar a comprar_divisas\n");
            System.out.println(moneda[0]);
            System.out.println(moneda[1]);
            System.out.println(moneda[2]);
            
            result=comprar_divisas(lista_servidor_moneda,lista_servidor_cantidad, lista_usuario_moneda,lista_usuario_cantidad, moneda[0],moneda[1],parseInt(moneda[2]));
            return result;
            
            
          } catch (Exception ex) {
            ex.printStackTrace();
        }
    }   
   
        return result;
    }
    
    
    
    
    
    private String listar_usuario(){
    String result ="";
     try {
            LineNumberReader input = new LineNumberReader(new FileReader("./datos/usuario.txt"));
            String line;
            while((line = input.readLine())!=null) {
                result=result+line;
                result=result+",";
            }
            input.close();
        } catch (Exception ex) {
               System.err.println("Excepcion en el archivo solicitado\n");
            ex.printStackTrace();
        }
    
    return result;
    }
      private String listar_sistema(){
    String result ="";
     try {
            LineNumberReader input = new LineNumberReader(new FileReader("./datos/sistema.txt"));
            String line;
            while((line = input.readLine())!=null) {
                result=result+line;
                result=result+",";
            }
            input.close();
        } catch (Exception ex) {
            System.err.println("Excepcion en el archivo solicitado\n");
            ex.printStackTrace();
        }
    
    return result;
    }
    private String listar_conversion(){
    String result ="";
    String palabra[];
     try {
            LineNumberReader input = new LineNumberReader(new FileReader("./datos/conversion.txt"));
            String line;
            result+="";
            while((line = input.readLine())!=null) {
                palabra=line.split(" ");
                result+=palabra[0]+"-"+palabra[1]+"-"+palabra[2]+",";
               // result=result+line;
                //result=result+"\n";
            }
            input.close();
        } catch (Exception ex) {
               System.err.println("Excepcion en el archivo solicitado\n");
            ex.printStackTrace();
        }
    return result;
    }
    
    public String listar(String op){
       String result=null;
        System.out.println(op);
        if(Integer.parseInt(op)<1 || Integer.parseInt(op)>3){
            
          result+="opcion Invalida\n";  
        
        }else{
            System.out.println("entre al principal else");
         switch(op){
            case "1":
                System.out.println("opcion 1");
                result=listar_usuario();
                break;
            case "2":
                result=listar_sistema();
                break;
            case "3":
                result=listar_conversion();
                break;
       
    
            }
        
        }
        
        
       
    return result;
    }
    
}