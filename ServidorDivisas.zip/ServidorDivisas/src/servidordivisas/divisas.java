
package servidordivisas;

import InterfazRemota.irDivisas;//importado por Libraries Add JAR/folder


public class divisas implements irDivisas{
    //constructor
    public divisas(){
        super();//construye igual como lo hace el padre
    }
    
    @Override
    public String comprar(String a, int b){
        String result=a+",asdasd.";
       
        
    if(b==1){
   
    //Inicialmente debo rescatar los datos del usuario y del server.
    /*
    entidad dinero_servidor[3];  //Creo un vector que me almacene los datos de dinero del servidor
	entidad dinero_usuario[3];	 //Creo un vector que me almacene los datos de dinero del usuario

	FILE * f=fopen("./datos/usuario.txt","a+");
	FILE * f2=fopen("./datos/sistema.txt","a+");	
	rescata_dinero(dinero_servidor,f2);  //Lleno el vector de dinero del servidor con los datos del almacen	
	rescata_dinero(dinero_usuario,f);    //Lleno el vector de dinero del usuario con los datos del almacen	

	
	for(i=0;i<3;i++){
	sprintf(resultado2, "%s %s", dinero_usuario[i].tipo_moneda, dinero_usuario[i].cantidad);	
	strcat(resultado, resultado2);
	strcat(resultado, "\n");
	}

	result = strdup(resultado);
	return &result;
	}
    
    */
        return result;
    }
	
    if(b==2){

    //Inicialmente debo rescatar los datos del usuario y del server.
    /*
    entidad dinero_servidor[3];  //Creo un vector que me almacene los datos de dinero del servidor
	entidad dinero_usuario[3];	 //Creo un vector que me almacene los datos de dinero del usuario
	char moneda_compra[4], moneda_pago[4], str[20];
	char * *result_1;
	char resultado[1000];
	int cantidad;
	char *v1, *v2, *v3;

	FILE * f=fopen("./datos/usuario.txt","a+");
	FILE * f2=fopen("./datos/sistema.txt","a+");	
	rescata_dinero(dinero_servidor,f2);  //Lleno el vector de dinero del servidor con los datos del almacen	
	rescata_dinero(dinero_usuario,f);    //Lleno el vector de dinero del usuario con los datos del almacen	

	sprintf(str,"%s",argp->str);         //Recupero el string que envie al server
	v1 = strtok(str, "-");
	v2 = strtok(NULL,"-");
	v3 = strtok(NULL,"-");

	result_1 = div_comprar(dinero_servidor,dinero_usuario,v1,v2,atoi(v3),f,f2);

	sprintf(resultado,"%s", (char *) *result_1);
	
	result = resultado;
	return &result;
	}
       */
     
        
        
        return result;
    }
        return result;
    }
}