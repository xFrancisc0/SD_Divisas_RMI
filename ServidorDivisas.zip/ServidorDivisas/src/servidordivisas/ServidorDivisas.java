/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidordivisas;

import InterfazRemota.irDivisas;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author pc0131
 */
public class ServidorDivisas {
    public ServidorDivisas(){
        try{
            /*  if(System.getSecurityManager()==null){
              System.setSecurityManager(new SecurityManager());

           }
*/              //Crea nombre para el objeto
           String nombre="divisas";
           //Crea el objeto y lo deja disponible para el cliente
           irDivisas divs= new divisas();//Polimorfismo: se inicializa con el metodo del hijo
           irDivisas stub=(irDivisas)UnicastRemoteObject.exportObject(divs,0);//generar el stub se necesita el objecto a exportar y el puerto
           //Sintetiza una referencia remota
           Registry registry = LocateRegistry.createRegistry(1099);
           registry.rebind(nombre,stub);
           //Si todo salio bien , se imprime un mensaje
           System.out.println("Servidor Corriendo...");
            }catch(Exception e){
                System.err.println("Excepcion en el servidor");
                e.printStackTrace();
            }
       
      }
       
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new ServidorDivisas();
    }
    
}
